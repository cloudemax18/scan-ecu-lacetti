package com.cheviexplorer.android.kwp

import com.cheviexplorer.android.DynamicBlockDefinitions
import com.cheviexplorer.android.DynamicBlockDefinitions.Block
import com.cheviexplorer.android.kwp.DynamicBlockResponseValidator.Verdict
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas ESTÁTICAS de lógica pura. No sustituyen una prueba en vehículo. */
class DynamicBlockResponseValidatorTest {
    private val f0 = Block.MR140_F0
    private val request = DynamicBlockDefinitions.buildDefinitionRequest(f0)

    private fun withChecksum(vararg b: Int): ByteArray {
        val body = b.map { it.toByte() }.toByteArray()
        val sum = body.sumOf { it.toInt() and 0xFF } and 0xFF
        return body + sum.toByte()
    }

    private fun verdict(rx: ByteArray?, block: Block = f0, echo: Boolean = true, req: ByteArray = DynamicBlockDefinitions.buildDefinitionRequest(block)) =
        DynamicBlockResponseValidator.validate(req, rx, block, echo).verdict

    private val ok = withChecksum(0x82, 0xF1, 0x11, 0x6C, 0xF0)

    @Test fun acceptsPositive6CWithEchoForEachMrBlock() {
        assertEquals(Verdict.ACCEPTED, verdict(request + ok))
        val f1 = Block.MR140_F1
        val reqF1 = DynamicBlockDefinitions.buildDefinitionRequest(f1)
        assertEquals(Verdict.ACCEPTED, verdict(reqF1 + withChecksum(0x82, 0xF1, 0x11, 0x6C, 0xF1), f1))
    }

    @Test fun acceptsExtendedLengthHeader() {
        assertEquals(Verdict.ACCEPTED, verdict(request + withChecksum(0x80, 0xF1, 0x11, 0x02, 0x6C, 0xF0)))
    }

    @Test fun acceptsWithoutEchoOnlyWhenEchoNotExpected() {
        assertEquals(Verdict.ACCEPTED, verdict(ok, echo = false))
        assertEquals(Verdict.ECHO_MISMATCH, verdict(ok, echo = true))
    }

    @Test fun rejectsNoResponseAndEchoOnly() {
        assertEquals(Verdict.NO_RESPONSE, verdict(null))
        assertEquals(Verdict.NO_RESPONSE, verdict(ByteArray(0)))
        assertEquals(Verdict.NO_RESPONSE, verdict(request))
    }

    @Test fun rejectsIncompleteEcho() {
        assertEquals(Verdict.TRUNCATED, verdict(request.copyOf(50)))
    }

    @Test fun rejectsEchoDifferentFromRequest() {
        val bad = request.copyOf(); bad[10] = (bad[10] + 1).toByte()
        assertEquals(Verdict.ECHO_MISMATCH, verdict(bad + ok))
    }

    @Test fun rejectsTruncatedResponse() {
        assertEquals(Verdict.TRUNCATED, verdict(request + ok.copyOf(ok.size - 1)))
        assertEquals(Verdict.TRUNCATED, verdict(request + byteArrayOf(0x80.toByte(), 0xF1.toByte())))
    }

    @Test fun rejectsBadChecksum() {
        val bad = ok.copyOf(); bad[bad.lastIndex] = (bad.last() + 1).toByte()
        assertEquals(Verdict.BAD_CHECKSUM, verdict(request + bad))
    }

    @Test fun rejectsWrongTargetAndWrongSource() {
        assertEquals(Verdict.WRONG_TARGET, verdict(request + withChecksum(0x82, 0x11, 0x11, 0x6C, 0xF0)))
        assertEquals(Verdict.WRONG_SOURCE, verdict(request + withChecksum(0x82, 0xF1, 0x18, 0x6C, 0xF0)))
        assertEquals(Verdict.WRONG_SOURCE, verdict(request + withChecksum(0x82, 0xF1, 0x00, 0x6C, 0xF0)))
    }

    @Test fun rejectsNegativeResponseTo2C() {
        val r = DynamicBlockResponseValidator.validate(request, request + withChecksum(0x83, 0xF1, 0x11, 0x7F, 0x2C, 0x31), f0)
        assertEquals(Verdict.NEGATIVE_RESPONSE, r.verdict)
        assertTrue(r.detail.contains("0x31"))
    }

    @Test fun rejectsInterleavedTesterPresentResponse() {
        val tp = withChecksum(0x81, 0xF1, 0x11, 0x7E)
        assertEquals(Verdict.TESTER_PRESENT_RESIDUAL, verdict(request + tp))
        // 7E primero y la respuesta real detrás: sigue siendo rechazo (fallar cerrado)
        assertEquals(Verdict.TESTER_PRESENT_RESIDUAL, verdict(request + tp + ok))
    }

    @Test fun rejectsResponsesBelongingToAnotherRequest() {
        assertEquals(Verdict.WRONG_SERVICE, verdict(request + withChecksum(0x82, 0xF1, 0x11, 0x61, 0xF0)))
        assertEquals(Verdict.OTHER_REQUEST, verdict(request + withChecksum(0x83, 0xF1, 0x11, 0x7F, 0x21, 0x31)))
        assertEquals(Verdict.WRONG_SERVICE, verdict(request + withChecksum(0x82, 0xF1, 0x11, 0x5A, 0x80)))
    }

    @Test fun rejectsWrongBlockId() {
        assertEquals(Verdict.WRONG_BLOCK, verdict(request + withChecksum(0x82, 0xF1, 0x11, 0x6C, 0xF1)))
    }

    @Test fun rejectsResidualBytesAfterValidResponse() {
        assertEquals(Verdict.RESIDUAL_BYTES, verdict(request + ok + withChecksum(0x81, 0xF1, 0x11, 0x7E)))
        assertEquals(Verdict.RESIDUAL_BYTES, verdict(request + ok + byteArrayOf(0x00)))
    }

    @Test fun rejectsMalformedFormatAndEmptyPayload() {
        assertEquals(Verdict.MALFORMED, verdict(request + withChecksum(0x02, 0xF1, 0x11, 0x6C, 0xF0)))
        assertEquals(Verdict.MALFORMED, verdict(request + withChecksum(0x80, 0xF1, 0x11, 0x00)))
        assertEquals(Verdict.MALFORMED, verdict(request + withChecksum(0x81, 0xF1, 0x11, 0x6C)))
    }

    @Test fun zfBlockExpectsZfEcuAsSource() {
        val zf = Block.ZF_F0
        val req = DynamicBlockDefinitions.buildDefinitionRequest(zf)
        assertEquals(Verdict.ACCEPTED, verdict(req + withChecksum(0x82, 0xF1, 0x18, 0x6C, 0xF0), zf))
        assertEquals(Verdict.WRONG_SOURCE, verdict(req + withChecksum(0x82, 0xF1, 0x11, 0x6C, 0xF0), zf))
    }
}
