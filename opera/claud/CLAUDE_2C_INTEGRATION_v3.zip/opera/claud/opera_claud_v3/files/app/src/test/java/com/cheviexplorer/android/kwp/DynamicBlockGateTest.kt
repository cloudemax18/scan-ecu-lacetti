package com.cheviexplorer.android.kwp

import com.cheviexplorer.android.DynamicBlockDefinitions.Block
import com.cheviexplorer.android.kwp.DynamicBlockGate.Completion
import com.cheviexplorer.android.kwp.DynamicBlockGate.Profile
import com.cheviexplorer.android.kwp.DynamicBlockGate.ResetReason
import com.cheviexplorer.android.kwp.DynamicBlockResponseValidator.Result
import com.cheviexplorer.android.kwp.DynamicBlockResponseValidator.Verdict
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DynamicBlockGateTest {
    private val accepted = Result(Verdict.ACCEPTED, "ok")
    private fun bad(v: Verdict) = Result(v, "x")

    private fun gateWithBothAccepted(policy: DynamicBlockGate.Policy = DynamicBlockGate.Policy()): Pair<DynamicBlockGate, Long> {
        val g = DynamicBlockGate(policy); val s = g.startSession(Profile.MR140)
        assertTrue(g.beginDefinition(Block.MR140_F0, s)); g.completeDefinition(Block.MR140_F0, s, accepted)
        assertTrue(g.beginDefinition(Block.MR140_F1, s)); g.completeDefinition(Block.MR140_F1, s, accepted)
        return g to s
    }

    @Test fun startsClosed() {
        val g = DynamicBlockGate()
        Block.values().forEach { assertFalse(g.canRead(it)); assertFalse(g.canPoll(it)) }
        assertNull(g.nextDefinition())
    }

    @Test fun mr140DefinesF0ThenF1AndOpensEachBlockIndividually() {
        val g = DynamicBlockGate(); val s = g.startSession(Profile.MR140)
        assertEquals(Block.MR140_F0, g.nextDefinition())
        assertTrue(g.beginDefinition(Block.MR140_F0, s))
        assertFalse(g.canRead(Block.MR140_F0))            // pendiente: aún cerrada
        assertNull(g.nextDefinition())                    // no se lanza otra a la vez
        assertEquals(Completion.ACCEPTED, g.completeDefinition(Block.MR140_F0, s, accepted))
        assertTrue(g.canRead(Block.MR140_F0)); assertFalse(g.canRead(Block.MR140_F1))
        assertEquals(Block.MR140_F1, g.nextDefinition())
        assertTrue(g.beginDefinition(Block.MR140_F1, s))
        assertEquals(Completion.ACCEPTED, g.completeDefinition(Block.MR140_F1, s, accepted))
        assertTrue(g.canRead(Block.MR140_F1)); assertNull(g.nextDefinition())
    }

    @Test fun f1CannotBeDefinedBeforeF0() {
        val g = DynamicBlockGate(); val s = g.startSession(Profile.MR140)
        assertFalse(g.beginDefinition(Block.MR140_F1, s))
        assertFalse(g.canRead(Block.MR140_F1))
    }

    @Test fun anyRejectedDefinitionClosesEverythingIncludingPreviouslyAcceptedF0() {
        for (v in Verdict.values().filter { it != Verdict.ACCEPTED }) {
            val g = DynamicBlockGate(); val s = g.startSession(Profile.MR140)
            g.beginDefinition(Block.MR140_F0, s); g.completeDefinition(Block.MR140_F0, s, accepted)
            g.beginDefinition(Block.MR140_F1, s)
            assertEquals(Completion.REJECTED_GATE_CLOSED, g.completeDefinition(Block.MR140_F1, s, bad(v)))
            assertFalse("F0 debe revocarse tras $v", g.canRead(Block.MR140_F0))
            assertFalse(g.canRead(Block.MR140_F1)); assertNull(g.nextDefinition())
            val expected = if (v == Verdict.NO_RESPONSE) ResetReason.TIMEOUT else ResetReason.INVALID_RESPONSE
            assertEquals(expected, g.lastResetReason())
        }
    }

    @Test fun everyResetReasonRevokesAccessAndBlocksNewDefinitions() {
        for (reason in ResetReason.values()) {
            val (g, _) = gateWithBothAccepted()
            assertTrue(g.canRead(Block.MR140_F0) && g.canRead(Block.MR140_F1))
            g.reset(reason)
            assertFalse("$reason", g.canRead(Block.MR140_F0)); assertFalse(g.canRead(Block.MR140_F1))
            assertNull(g.nextDefinition()); assertEquals(reason, g.lastResetReason())
        }
    }

    @Test fun newSessionAfterReconnectStartsFromScratch() {
        val (g, _) = gateWithBothAccepted()
        val s2 = g.startSession(Profile.MR140)
        assertEquals(ResetReason.SESSION_RESTART, g.lastResetReason())
        assertFalse(g.canRead(Block.MR140_F0)); assertFalse(g.canRead(Block.MR140_F1))
        assertEquals(Block.MR140_F0, g.nextDefinition()); assertTrue(g.currentSessionId() == s2)
    }

    @Test fun profileChangeResets() {
        val (g, _) = gateWithBothAccepted()
        g.onProfileChange(Profile.MR140)                  // mismo perfil: no cambia nada
        assertTrue(g.canRead(Block.MR140_F0))
        g.onProfileChange(Profile.ZF)
        assertFalse(g.canRead(Block.MR140_F0)); assertEquals(ResetReason.PROFILE_CHANGE, g.lastResetReason())
    }

    @Test fun staleCompletionAfterResetIsIgnoredAndDoesNotOpenNewSession() {
        val g = DynamicBlockGate(); val s1 = g.startSession(Profile.MR140)
        assertTrue(g.beginDefinition(Block.MR140_F0, s1))
        g.reset(ResetReason.DISCONNECT)                   // desconexión con la definición en vuelo
        assertEquals(Completion.IGNORED_STALE, g.completeDefinition(Block.MR140_F0, s1, accepted))
        assertFalse(g.canRead(Block.MR140_F0))
        val s2 = g.startSession(Profile.MR140)
        assertFalse(g.beginDefinition(Block.MR140_F0, s1)) // ticket viejo
        assertEquals(Completion.IGNORED_STALE, g.completeDefinition(Block.MR140_F0, s1, accepted))
        assertTrue(g.beginDefinition(Block.MR140_F0, s2))
    }

    @Test fun completionForNonPendingBlockIsIgnored() {
        val g = DynamicBlockGate(); val s = g.startSession(Profile.MR140)
        assertEquals(Completion.IGNORED_STALE, g.completeDefinition(Block.MR140_F0, s, accepted))
        assertFalse(g.canRead(Block.MR140_F0))
    }

    @Test fun zfIsBlockedByDefaultPolicy() {
        val g = DynamicBlockGate(); val s = g.startSession(Profile.ZF)
        assertNull(g.nextDefinition()); assertFalse(g.beginDefinition(Block.ZF_F0, s))
        assertFalse(g.canRead(Block.ZF_F0)); assertFalse(g.canPoll(Block.ZF_F0))
    }

    @Test fun zfPolicyDisabledStillBlocksEvenIfSomehowAccepted() {
        val on = DynamicBlockGate(DynamicBlockGate.Policy(zfEnabled = true)); val s = on.startSession(Profile.ZF)
        assertEquals(Block.ZF_F0, on.nextDefinition())     // la política existe pero NO es el valor por defecto
        assertTrue(on.beginDefinition(Block.ZF_F0, s)); on.completeDefinition(Block.ZF_F0, s, accepted)
        assertTrue(on.canRead(Block.ZF_F0))
        val off = DynamicBlockGate(DynamicBlockGate.Policy(zfEnabled = false)); val s2 = off.startSession(Profile.ZF)
        assertFalse(off.beginDefinition(Block.ZF_F0, s2)); assertFalse(off.canRead(Block.ZF_F0))
    }

    @Test fun blocksOfOtherProfileAreNeverReadable() {
        val (g, _) = gateWithBothAccepted()
        assertFalse(g.canRead(Block.ZF_F0))
        val z = DynamicBlockGate(DynamicBlockGate.Policy(zfEnabled = true)); val s = z.startSession(Profile.ZF)
        z.beginDefinition(Block.ZF_F0, s); z.completeDefinition(Block.ZF_F0, s, accepted)
        assertFalse(z.canRead(Block.MR140_F0)); assertFalse(z.canRead(Block.MR140_F1))
    }
}
