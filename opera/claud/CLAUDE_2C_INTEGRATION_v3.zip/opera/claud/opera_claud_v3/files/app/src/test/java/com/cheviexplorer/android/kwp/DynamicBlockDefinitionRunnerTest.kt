package com.cheviexplorer.android.kwp

import com.cheviexplorer.android.DynamicBlockDefinitions
import com.cheviexplorer.android.DynamicBlockDefinitions.Block
import com.cheviexplorer.android.kwp.DynamicBlockGate.Profile
import com.cheviexplorer.android.kwp.DynamicBlockGate.ResetReason
import com.cheviexplorer.android.kwp.DynamicBlockResponseValidator.Verdict
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DynamicBlockDefinitionRunnerTest {
    private fun withChecksum(vararg b: Int): ByteArray {
        val body = b.map { it.toByte() }.toByteArray()
        return body + ((body.sumOf { it.toInt() and 0xFF }) and 0xFF).toByte()
    }
    private fun ok(block: Block) = withChecksum(0x82, 0xF1, block.targetAddress, 0x6C, block.blockId)

    private class FakeTransport(val reply: (ByteArray, Int) -> ByteArray?) : DefinitionTransport {
        val requests = mutableListOf<ByteArray>()
        override fun exchange(request: ByteArray, timeoutMs: Long): ByteArray? {
            requests += request
            return reply(request, requests.size)
        }
    }

    private fun setup(transport: DefinitionTransport): Triple<DynamicBlockGate, DynamicBlockDefinitionRunner, Long> {
        val gate = DynamicBlockGate(); val session = gate.startSession(Profile.MR140)
        return Triple(gate, DynamicBlockDefinitionRunner(gate, SerialTransactionOwner(), transport), session)
    }

    @Test fun definesF0ThenF1InOrderAndOpensGate() {
        val t = FakeTransport { req, n -> req + ok(if (n == 1) Block.MR140_F0 else Block.MR140_F1) }
        val (gate, runner, s) = setup(t)
        val steps = runner.defineAll(s)
        assertEquals(listOf(Block.MR140_F0, Block.MR140_F1), steps.map { it.block })
        assertTrue(steps.all { it.result!!.accepted })
        assertEquals(DynamicBlockDefinitions.buildDefinitionRequest(Block.MR140_F0).toList(), t.requests[0].toList())
        assertEquals(DynamicBlockDefinitions.buildDefinitionRequest(Block.MR140_F1).toList(), t.requests[1].toList())
        assertTrue(gate.canRead(Block.MR140_F0) && gate.canRead(Block.MR140_F1))
    }

    @Test fun f1IsNotSentWhenF0IsRejected() {
        val t = FakeTransport { req, _ -> req + withChecksum(0x83, 0xF1, 0x11, 0x7F, 0x2C, 0x31) }
        val (gate, runner, s) = setup(t)
        val steps = runner.defineAll(s)
        assertEquals(1, t.requests.size); assertEquals(Verdict.NEGATIVE_RESPONSE, steps.single().result!!.verdict)
        assertFalse(gate.canRead(Block.MR140_F0)); assertFalse(gate.canRead(Block.MR140_F1))
    }

    @Test fun f1RejectionRevokesF0() {
        val t = FakeTransport { req, n -> if (n == 1) req + ok(Block.MR140_F0) else req + withChecksum(0x81, 0xF1, 0x11, 0x7E) }
        val (gate, runner, s) = setup(t)
        val steps = runner.defineAll(s)
        assertEquals(Verdict.TESTER_PRESENT_RESIDUAL, steps.last().result!!.verdict)
        assertFalse(gate.canRead(Block.MR140_F0)); assertFalse(gate.canRead(Block.MR140_F1))
    }

    @Test fun timeoutClosesGateWithTimeoutReason() {
        val t = FakeTransport { req, _ -> req }              // solo eco
        val (gate, runner, s) = setup(t)
        runner.defineAll(s)
        assertEquals(ResetReason.TIMEOUT, gate.lastResetReason()); assertFalse(gate.canRead(Block.MR140_F0))
    }

    @Test fun ioErrorClosesGateAndStops() {
        val t = FakeTransport { _, _ -> throw IOException("usb perdido") }
        val (gate, runner, s) = setup(t)
        val steps = runner.defineAll(s)
        assertEquals("usb perdido", steps.single().ioError); assertNull(steps.single().result)
        assertEquals(ResetReason.IO_ERROR, gate.lastResetReason()); assertEquals(1, t.requests.size)
    }

    @Test fun staleSessionSendsNothing() {
        val t = FakeTransport { req, _ -> req + ok(Block.MR140_F0) }
        val (gate, runner, s) = setup(t)
        gate.reset(ResetReason.DISCONNECT)
        assertTrue(runner.defineAll(s).isEmpty()); assertTrue(t.requests.isEmpty())
    }

    @Test fun zfSendsNothingByDefault() {
        val t = FakeTransport { req, _ -> req + ok(Block.ZF_F0) }
        val gate = DynamicBlockGate(); val s = gate.startSession(Profile.ZF)
        val runner = DynamicBlockDefinitionRunner(gate, SerialTransactionOwner(), t)
        assertTrue(runner.defineAll(s).isEmpty()); assertTrue(t.requests.isEmpty())
    }

    @Test fun testerPresentCannotInterleaveWhileDefinitionsRun() {
        val owner = SerialTransactionOwner()
        val inside = CountDownLatch(1); val release = CountDownLatch(1); val tpRan = AtomicBoolean(false)
        val t = DefinitionTransport { req, _ ->
            inside.countDown(); release.await(2, TimeUnit.SECONDS)
            req + ok(Block.MR140_F0)
        }
        val gate = DynamicBlockGate(); val s = gate.startSession(Profile.MR140)
        val runner = DynamicBlockDefinitionRunner(gate, owner, t)
        val worker = Thread { runner.defineAll(s) }; worker.start()
        assertTrue(inside.await(2, TimeUnit.SECONDS))
        assertEquals(DynamicBlockDefinitionRunner.OWNER_NAME, owner.busyOwner())
        val ran = owner.tryRun("TP") { tpRan.set(true) }
        assertFalse(ran); assertFalse(tpRan.get())          // el latido se omite, no consume respuestas ajenas
        release.countDown(); worker.join(3000)
        assertTrue(owner.tryRun("TP") { tpRan.set(true) }); assertTrue(tpRan.get())
        assertNull(owner.busyOwner())
    }

    @Test fun ownerSerializesConcurrentTransactions() {
        val owner = SerialTransactionOwner()
        val active = java.util.concurrent.atomic.AtomicInteger(0); val maxActive = java.util.concurrent.atomic.AtomicInteger(0)
        val threads = (1..6).map {
            Thread { repeat(20) { owner.run("t") { val n = active.incrementAndGet(); maxActive.accumulateAndGet(n) { a, b -> maxOf(a, b) }; Thread.yield(); active.decrementAndGet() } } }
        }
        threads.forEach { it.start() }; threads.forEach { it.join(5000) }
        assertEquals(1, maxActive.get())
    }
}
